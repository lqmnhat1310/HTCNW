<div class="container">
	<a href="#" target="_blank"> 
		<img src="images/clients/twitterLogo.jpg" alt="business template">
	</a> 
	<a href="#" target="_blank">
		<img src="images/clients/googleLogo.jpg" alt="business template">
	</a> 
	<a href="#" target="_blank">
		<img src="images/clients/facebookLogo.jpg" alt="business template">
	</a> 
	<a href="#" target="_blank">
		<img src="images/clients/my_web_solution.jpg" alt="business template">
	</a>
</div>