<div class="container">
	<div class="row title">
		<h3>What we do?</h3>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odit dignissimos commodi eius adipisci soluta facilis voluptatem cum repellat ut sapiente.</p>
	</div>
	<div class="row">
		<div class="col-md-2">
			<div class="well well-small">
				<h4 data-container="body" data-toggle="popover" data-placement="top" 
					data-content="> ABC <br />> DEF <br />> GEH"
					data-original-title="Boostrap is easy "
				>
					<i class="fa fa-magic"></i>
					<span>Design</span>
				</h4>
				<a href="#">view detail</a>
				<div class="popover-title" style="display: none;"><h3>ABC</h3></div>
				<ul class="popover-content"  style="display: none;">
					<li>123</li>
					<li>456</li>
					<li>789</li>
				</ul>
			</div>
		</div>
		<div class="col-md-2">
			<div class="well well-small">
				<h4 id="popover-2">
					<i class="fa fa-link"></i>
					<span>SEO</span>
				</h4>
				<a href="#">view detail</a>
			</div>
		</div>
		<div class="col-md-2">
			<div class="well well-small">
				<h4>
					<i class="fa fa-magic"></i>
					<span>Design</span>
				</h4>
				<a href="#">view detail</a>
			</div>
		</div>
		<div class="col-md-2">
			<div class="well well-small">
				<h4>
					<i class="fa fa-magic"></i>
					<span>Design</span>
				</h4>
				<a href="#">view detail</a>
			</div>
		</div>
		<div class="col-md-2">
			<div class="well well-small">
				<h4>
					<i class="fa fa-magic"></i>
					<span>Design</span>
				</h4>
				<a href="#">view detail</a>
			</div>
		</div>
		<div class="col-md-2">
			<div class="well well-small">
				<h4>
					<i class="fa fa-magic"></i>
					<span>Design</span>
				</h4>
				<a href="#">view detail</a>
			</div>
		</div>
	</div>
</div>