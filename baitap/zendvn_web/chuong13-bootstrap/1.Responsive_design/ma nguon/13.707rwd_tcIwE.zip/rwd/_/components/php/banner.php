<div class="container">
	<a href="#" target="_blank"> 
		<img src="_/components/images/clients/twitterLogo.jpg" alt="business template">
	</a> 
	<a href="#" target="_blank">
		<img src="_/components/images/clients/googleLogo.jpg" alt="business template">
	</a> 
	<a href="#" target="_blank">
		<img src="_/components/images/clients/facebookLogo.jpg" alt="business template">
	</a> 
	<a href="#" target="_blank">
		<img src="_/components/images/clients/my_web_solution.jpg" alt="business template">
	</a>
</div>