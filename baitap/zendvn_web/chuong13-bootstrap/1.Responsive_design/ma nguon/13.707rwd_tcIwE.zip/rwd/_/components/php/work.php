<div class="container">
	<div class="row">
		<h3>
			Our Recent Work <small>view all projects (200+)</small>
		</h3>
		<div class="col-md-4 col-sm-4">
			<div class="thumbnail">
				<h4>Mobile Apps</h4>
				<a href="#"><img src="_/components/images/1.jpg" alt="bootstrap business templates"></a>
				<div class="caption">
					<p>We specialise in web design, web development and graphic design for different Desktop, Mobiles and Tablets. We recently	introduce cheapest and best mobile web design packages in our services</p>
					<div class="btn-group">
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="right" data-original-title="send email">
							<i class="fa fa-envelope"></i>
						</a>
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="top" data-original-title="do you like?">
							<i class="fa fa-thumbs-up"></i>
						</a>
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="top" data-original-title="dont like?">
							<i class="fa fa-thumbs-down"></i>
						</a>
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="top" data-original-title="share">
							<i class="fa fa-link"></i>
						</a> 
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="left" data-original-title="browse">
							<i class="fa fa-globe"></i>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-4 col-sm-4">
			<div class="thumbnail">
				<h4>Mobile Apps</h4>
				<a href="#"><img src="_/components/images/2.jpg" alt="bootstrap business templates"></a>
				<div class="caption">
					<p>We specialise in web design, web development and graphic design for different Desktop, Mobiles and Tablets. We recently	introduce cheapest and best mobile web design packages in our services</p>
					<div class="btn-group">
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="right" data-original-title="send email">
							<i class="fa fa-envelope"></i>
						</a>
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="top" data-original-title="do you like?">
							<i class="fa fa-thumbs-up"></i>
						</a>
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="top" data-original-title="dont like?">
							<i class="fa fa-thumbs-down"></i>
						</a>
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="top" data-original-title="share">
							<i class="fa fa-link"></i>
						</a> 
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="left" data-original-title="browse">
							<i class="fa fa-globe"></i>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-4 col-sm-4">
			<div class="thumbnail">
				<h4>Mobile Apps</h4>
				<a href="#"><img src="_/components/images/3.jpg" alt="bootstrap business templates"></a>
				<div class="caption">
					<p>We specialise in web design, web development and graphic design for different Desktop, Mobiles and Tablets. We recently	introduce cheapest and best mobile web design packages in our services</p>
					<div class="btn-group">
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="right" data-original-title="send email">
							<i class="fa fa-envelope"></i>
						</a>
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="top" data-original-title="do you like?">
							<i class="fa fa-thumbs-up"></i>
						</a>
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="top" data-original-title="dont like?">
							<i class="fa fa-thumbs-down"></i>
						</a>
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="top" data-original-title="share">
							<i class="fa fa-link"></i>
						</a> 
						<a class="btn btn-default" href="#" data-toggle="tooltip" data-placement="left" data-original-title="browse">
							<i class="fa fa-globe"></i>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>